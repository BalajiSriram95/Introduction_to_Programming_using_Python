import datetime

def diff_month(d1, d2):
    return ((d1.year - d2.year) * 12 + d1.month - d2.month) / 12

def read_team_details(readfile):
    team_detail_items = open(readfile, 'r')
    team_detail_dist = {}
    index = 0
    for item in team_detail_items:
        if item.strip() != '---eod---':
            dist = item.split(':')
            #get the individual item after split with char (:)
            #print(dist)
            #add those items as key and value to dictionary
            if dist[0].strip() == 'DoJInKGS':
                team_detail_dist[dist[0].strip()] = datetime.datetime.strptime(dist[1].strip(), "%d-%m-%Y").date()
            else:
                team_detail_dist[dist[0].strip()] = dist[1].strip()
        else:
            #display dictionary once emp details is over
            #print(team_detail_dist)
            #add dictionary to list
            team_details_list.append(team_detail_dist)
            #display list after every individual item has been added
            #print(team_details_list)
            index += 1
            #once added dictionary re-initialize to empty
            team_detail_dist = {}
    #display list once read all items from txt file
    print(team_details_list)
    #close the txt file after complete txt file read
    team_detail_items.close()

def write_log_book(writefile):
    file = open(writefile, 'w')
    for index, dist_item in enumerate(team_details_list):
        years = '{:.1f}'.format(diff_month(datetime.date.today(), dist_item['DoJInKGS']))
        print('Employee %s has joined in %s and his KGS experience is %s yrs \n' % (
        	dist_item['EmpName'], dist_item['DoJInKGS'].strftime("%d-%m-%Y"), years))
        	file.write('Employee %s has joined in %s and his KGS experience is %s yrs \n' % (
        	dist_item['EmpName'], dist_item['DoJInKGS'].strftime("%d-%m-%Y"), years))
    file.close()

# initialize the list
team_details_list = []

# call the method to read line from txt file
input_file = 'C:\\Users\\balajisriram\\Desktop\\Introduction_to_Programming_using_Python\\Assignment\\Input.txt'
read_team_details(input_file)

# call the method to write lines to txt file
output_file = 'C:\\Users\\balajisriram\\Desktop\\Introduction_to_Programming_using_Python\\Assignment\\output.txt'
write_log_book(output_file)




